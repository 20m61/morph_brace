//
//  morph_blassTests.h
//  morph_blassTests
//
//  Created by ゆかいなおじさん.com on 13/02/05.
//  Copyright (c) 2013年 cnghwi. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface morph_blassTests : SenTestCase

@end
