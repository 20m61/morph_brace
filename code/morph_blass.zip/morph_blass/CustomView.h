//
//  CustomView.h
//  ScrollViewPaging
//
//  Created by Hiroshi Hashiguchi on 10/10/06.
//  Copyright 2010 . All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomView : UIView {

	UIColor* color;
}

@end
